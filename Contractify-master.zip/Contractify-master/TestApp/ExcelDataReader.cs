﻿using System;
using System.Data;
using System.IO;
using ClosedXML.Excel;

namespace TestApp
{
	public class ExcelReader
	{
		public DataSet ReadExcelSheet(string filePath)
		{
			DataSet dataSet = new DataSet();

			using (var workbook = new XLWorkbook(filePath))
			{
				var worksheet = workbook.Worksheet(1);
				int rowCount = worksheet.RowCount();
				int lastColumn = worksheet.LastColumnUsed().ColumnNumber();

				int currentTableStartRow = 0;
				int currentTableEndRow = 0;
				int currentTableStartCol = 0;
				int currentTableEndCol = 0;
				if (rowCount > 0)
				{
					for (int row = 1; row <= rowCount; row++)
					{
						IXLRow currentRow = worksheet.Row(row);
						int firstColumn = currentRow.FirstCellUsed().Address.ColumnNumber;
						int lastRowColumn = currentRow.LastCellUsed().Address.ColumnNumber;

						if (firstColumn == lastRowColumn)
						{
							// This row is empty, so it could be the end of a table
							if (currentTableStartRow != 0)
							{
								// If we have started a table, end it and add it to the DataSet
								currentTableEndRow = row - 1;
								currentTableEndCol = lastColumn;
								DataTable table = GetTable(worksheet, currentTableStartRow, currentTableEndRow, currentTableStartCol, currentTableEndCol);
								dataSet.Tables.Add(table);

								// Reset variables for next table
								currentTableStartRow = 0;
								currentTableEndRow = 0;
								currentTableStartCol = 0;
								currentTableEndCol = 0;
							}
						}
						else
						{
							// This row has data, so it could be the start of a table
							if (currentTableStartRow == 0)
							{
								// If we haven't started a table, start one
								currentTableStartRow = row;
								currentTableStartCol = firstColumn;
							}
						}
					}

					// Add the last table to the DataSet
					if (currentTableStartRow != 0)
					{
						currentTableEndRow = rowCount;
						currentTableEndCol = lastColumn;
						DataTable table = GetTable(worksheet, currentTableStartRow, currentTableEndRow, currentTableStartCol, currentTableEndCol);
						dataSet.Tables.Add(table);
					}
				}
			}

			return dataSet;
		}

		private static DataTable GetTable(IXLWorksheet worksheet, int startRow, int endRow, int startCol, int endCol)
		{
			DataTable table = new DataTable();

			for (int col = startCol; col <= endCol; col++)
			{
				table.Columns.Add(worksheet.Cell(startRow, col).Value.ToString());
			}

			for (int row = startRow + 1; row <= endRow; row++)
			{
				DataRow dataRow = table.NewRow();

				for (int col = startCol; col <= endCol; col++)
				{
					dataRow[col - startCol] = worksheet.Cell(row, col).Value.ToString();
				}

				table.Rows.Add(dataRow);
			}

			return table;
		}

	}
}
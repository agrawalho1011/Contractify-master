using System.Data;

namespace TestApp
{
	public partial class Form1 : Form
	{

		ExcelReader read = new ExcelReader();

		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			OpenFileDialog fileDialog =	new OpenFileDialog();
			if(fileDialog.ShowDialog() == DialogResult.OK )
			{
				DataSet ds = read.ReadExcelSheet(fileDialog.FileName);
			}
		}
	}
}
﻿

namespace DataModel.Output
{
	public class Mainleg
	{
		public string cf_cdup { get; set; }
		public string ValidityFrom { get; set; }
		public string ValidityTo { get; set; }
		public string LineItemId { get; set; }
		public string OriginLocations { get; set; }
		public string ViaOrigin { get; set; }
		public string ViaDestination { get; set; }
		public string DestinationLocations { get; set; }
		public string HaulageDestination { get; set; }
		public string Loops { get; set; }
		public string Currency { get; set; }
		public double? DC_20_Price { get; set; }
		public double? DC_40_Price { get; set; }
		public double? HC_40_Price { get; set; }
		public double? RE_20_Price { get; set; }
		public double? Rh_40_Price { get; set; }
		public double? HCNOR_40_Price { get; set; }
		public string DC_20_PricingType { get; set; }
		public string DC_40_PricingType { get; set; }
		public string HC_40_PricingType { get; set; }
		public string RE_20_PricingType { get; set; }
		public string Rh_40_PricingType { get; set; }
		public string HCNOR_40_PricingType { get; set; }
		public string hc_45_PricingType { get; set; }
		public string RATEREMARKS { get; set; }
	}
}

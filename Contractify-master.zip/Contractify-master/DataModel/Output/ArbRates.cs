﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.Output
{
	public class ArbRates
	{
		public string cf_cdup { get; set; }
		public DateTime ValidityFrom { get; set; }
		public DateTime ValidityTo { get; set; }
		public string LineitemId { get; set; }
		public string OriginShipmentType { get; set; }
		public string DestinationShipmentType { get; set; }
		public string OriginLocations { get; set; }
		public string ViaOrigin { get; set; }
		public string ViaDestination { get; set; }
		public string DestinationRoutingInfo { get; set; }
		public string DestinationLocations { get; set; }
		public string Currency { get; set; }
		public double? DC_20_Price { get; set; }
		public double? DC_40_Price { get; set; }
		public double? HC_40_Price { get; set; }
		public double? RE_20_Price { get; set; }
		public double? RE_40_Price { get; set; }
		public double? rh_40_Price { get; set; }
		public double? NOR_40_Price { get; set; }
		public string DC_20_PricingType { get; set; }
		public string DC_40_PricingType { get; set; }
		public string HC_40_PricingType { get; set; }
		public string RE_20_PricingType { get; set; }
		public string Rh_40_PricingType { get; set; }
		public string NOR_40_PricingType { get; set; }
		public string RateRemarks { get; set; }
		public string OtherGeosideRestriction { get; set; }
	}

}

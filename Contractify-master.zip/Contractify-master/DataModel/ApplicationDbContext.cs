﻿namespace DataModel
{
	public class ApplicationDbContext
	{

	}
}